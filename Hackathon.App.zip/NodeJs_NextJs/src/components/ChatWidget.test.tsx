import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ChatWidget from './ChatWidget';

// Mock fetch
const mockFetch = global.fetch as jest.Mock;

describe('ChatWidget', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockFetch.mockReset();
  });

  describe('Initial State', () => {
    it('should render the chat button', () => {
      render(<ChatWidget />);
      
      // Should show chat button (closed state)
      expect(screen.getByRole('button')).toBeInTheDocument();
    });

    it('should be closed by default', () => {
      render(<ChatWidget />);
      
      // Chat container should not be visible
      expect(screen.queryByPlaceholderText(/พิมพ์ข้อความ/i)).not.toBeInTheDocument();
    });

    it('should have no messages initially', () => {
      render(<ChatWidget />);
      
      // Open chat first
      const chatButton = screen.getByRole('button');
      fireEvent.click(chatButton);
      
      // Should not have any message elements (except quick actions)
      expect(screen.queryByText(/user:/i)).not.toBeInTheDocument();
    });
  });

  describe('Toggle Functionality', () => {
    it('should open chat when clicking the button', () => {
      render(<ChatWidget />);
      
      const chatButton = screen.getByRole('button');
      fireEvent.click(chatButton);
      
      // Input should now be visible
      expect(screen.getByPlaceholderText(/พิมพ์ข้อความ/i)).toBeInTheDocument();
    });

    it('should close chat when clicking close button', () => {
      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      // Find and click close button (X)
      const closeButton = screen.getByText('×');
      fireEvent.click(closeButton);
      
      // Input should no longer be visible
      expect(screen.queryByPlaceholderText(/พิมพ์ข้อความ/i)).not.toBeInTheDocument();
    });
  });

  describe('Message Sending', () => {
    it('should not send empty messages', async () => {
      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      const input = screen.getByPlaceholderText(/พิมพ์ข้อความ/i);
      const sendButton = screen.getByText('ส่ง');
      
      // Try to send empty message
      fireEvent.click(sendButton);
      
      expect(mockFetch).not.toHaveBeenCalled();
    });

    it('should send message and display user message', async () => {
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ 
          success: true, 
          answer: 'Test response from AI' 
        }),
      });

      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      const input = screen.getByPlaceholderText(/พิมพ์ข้อความ/i);
      
      // Type message
      await userEvent.type(input, 'Hello AI');
      
      // Send message
      const sendButton = screen.getByText('ส่ง');
      fireEvent.click(sendButton);
      
      // User message should appear
      await waitFor(() => {
        expect(screen.getByText('Hello AI')).toBeInTheDocument();
      });
    });

    it('should clear input after sending', async () => {
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ success: true, answer: 'Response' }),
      });

      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      const input = screen.getByPlaceholderText(/พิมพ์ข้อความ/i) as HTMLInputElement;
      
      await userEvent.type(input, 'Test message');
      fireEvent.click(screen.getByText('ส่ง'));
      
      await waitFor(() => {
        expect(input.value).toBe('');
      });
    });

    it('should display AI response after sending', async () => {
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ 
          success: true, 
          answer: 'This is the AI response' 
        }),
      });

      render(<ChatWidget />);
      
      // Open chat and send message
      fireEvent.click(screen.getByRole('button'));
      await userEvent.type(screen.getByPlaceholderText(/พิมพ์ข้อความ/i), 'Question');
      fireEvent.click(screen.getByText('ส่ง'));
      
      // Wait for AI response
      await waitFor(() => {
        expect(screen.getByText('This is the AI response')).toBeInTheDocument();
      });
    });

    it('should handle API errors gracefully', async () => {
      mockFetch.mockRejectedValueOnce(new Error('Network error'));

      render(<ChatWidget />);
      
      // Open chat and send message
      fireEvent.click(screen.getByRole('button'));
      await userEvent.type(screen.getByPlaceholderText(/พิมพ์ข้อความ/i), 'Question');
      fireEvent.click(screen.getByText('ส่ง'));
      
      // Wait for error message
      await waitFor(() => {
        expect(screen.getByText(/เกิดข้อผิดพลาด/)).toBeInTheDocument();
      });
    });

    it('should handle API error response', async () => {
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ 
          success: false, 
          error: 'Server error' 
        }),
      });

      render(<ChatWidget />);
      
      // Open chat and send message
      fireEvent.click(screen.getByRole('button'));
      await userEvent.type(screen.getByPlaceholderText(/พิมพ์ข้อความ/i), 'Question');
      fireEvent.click(screen.getByText('ส่ง'));
      
      // Wait for error to be displayed
      await waitFor(() => {
        expect(screen.getByText(/เกิดข้อผิดพลาด/)).toBeInTheDocument();
      });
    });

    it('should send message on Enter key press', async () => {
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ success: true, answer: 'Response' }),
      });

      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      const input = screen.getByPlaceholderText(/พิมพ์ข้อความ/i);
      
      await userEvent.type(input, 'Test message');
      fireEvent.keyPress(input, { key: 'Enter', code: 'Enter', charCode: 13 });
      
      await waitFor(() => {
        expect(mockFetch).toHaveBeenCalled();
      });
    });

    it('should not send on Shift+Enter', async () => {
      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      const input = screen.getByPlaceholderText(/พิมพ์ข้อความ/i);
      
      await userEvent.type(input, 'Test message');
      fireEvent.keyPress(input, { key: 'Enter', code: 'Enter', charCode: 13, shiftKey: true });
      
      expect(mockFetch).not.toHaveBeenCalled();
    });
  });

  describe('Quick Actions', () => {
    it('should display quick action buttons', () => {
      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      // Check for quick action buttons
      expect(screen.getByText(/อัตราแลกเปลี่ยนวันนี้/i)).toBeInTheDocument();
      expect(screen.getByText(/สินเชื่อส่งออก/i)).toBeInTheDocument();
      expect(screen.getByText(/Letter of Credit/i)).toBeInTheDocument();
    });

    it('should send quick action message when clicked', async () => {
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ success: true, answer: 'Exchange rate info' }),
      });

      render(<ChatWidget />);
      
      // Open chat
      fireEvent.click(screen.getByRole('button'));
      
      // Click quick action
      const quickAction = screen.getByText(/อัตราแลกเปลี่ยนวันนี้/i);
      fireEvent.click(quickAction);
      
      await waitFor(() => {
        expect(mockFetch).toHaveBeenCalledWith('/api/chat/ask', expect.objectContaining({
          method: 'POST',
          body: expect.stringContaining('อัตราแลกเปลี่ยนวันนี้'),
        }));
      });
    });
  });

  describe('Clear Chat', () => {
    it('should clear all messages when clear button is clicked', async () => {
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ success: true, answer: 'Response' }),
      });

      render(<ChatWidget />);
      
      // Open chat and send a message
      fireEvent.click(screen.getByRole('button'));
      await userEvent.type(screen.getByPlaceholderText(/พิมพ์ข้อความ/i), 'Test');
      fireEvent.click(screen.getByText('ส่ง'));
      
      await waitFor(() => {
        expect(screen.getByText('Test')).toBeInTheDocument();
      });
      
      // Clear chat
      const clearButton = screen.getByText('🗑️');
      fireEvent.click(clearButton);
      
      // Messages should be cleared
      expect(screen.queryByText('Test')).not.toBeInTheDocument();
    });
  });

  describe('Loading State', () => {
    it('should show loading indicator while waiting for response', async () => {
      // Create a promise that we can control
      let resolvePromise: (value: any) => void;
      const pendingPromise = new Promise((resolve) => {
        resolvePromise = resolve;
      });
      
      mockFetch.mockReturnValueOnce({
        json: () => pendingPromise,
      });

      render(<ChatWidget />);
      
      // Open chat and send message
      fireEvent.click(screen.getByRole('button'));
      await userEvent.type(screen.getByPlaceholderText(/พิมพ์ข้อความ/i), 'Question');
      fireEvent.click(screen.getByText('ส่ง'));
      
      // Should show loading state
      await waitFor(() => {
        expect(screen.getByText(/กำลังคิด/i)).toBeInTheDocument();
      });
      
      // Resolve the promise
      resolvePromise!({ success: true, answer: 'Response' });
    });

    it('should disable send button while loading', async () => {
      let resolvePromise: (value: any) => void;
      const pendingPromise = new Promise((resolve) => {
        resolvePromise = resolve;
      });
      
      mockFetch.mockReturnValueOnce({
        json: () => pendingPromise,
      });

      render(<ChatWidget />);
      
      // Open chat and send message
      fireEvent.click(screen.getByRole('button'));
      await userEvent.type(screen.getByPlaceholderText(/พิมพ์ข้อความ/i), 'Question');
      fireEvent.click(screen.getByText('ส่ง'));
      
      // Send button should be disabled
      await waitFor(() => {
        const sendButton = screen.getByText('ส่ง');
        expect(sendButton).toBeDisabled();
      });
      
      resolvePromise!({ success: true, answer: 'Response' });
    });
  });

  describe('Unread Count', () => {
    it('should increment unread count when message received and chat is closed', async () => {
      // This test would require checking the badge, but the component 
      // needs to expose this state or render it in the UI
      mockFetch.mockResolvedValueOnce({
        json: () => Promise.resolve({ success: true, answer: 'Response' }),
      });

      render(<ChatWidget />);
      
      // Open chat, send message, then close
      fireEvent.click(screen.getByRole('button'));
      await userEvent.type(screen.getByPlaceholderText(/พิมพ์ข้อความ/i), 'Test');
      fireEvent.click(screen.getByText('ส่ง'));
      
      // Close chat before response arrives
      fireEvent.click(screen.getByText('×'));
      
      // Wait for response
      await waitFor(() => {
        // Check for unread badge if it exists in the UI
        const badge = screen.queryByText('1');
        // Badge might show unread count
      });
    });
  });
});
