// Re-export all pipes
export * from './file-size.pipe';
export * from './time-ago.pipe';
export * from './truncate.pipe';
